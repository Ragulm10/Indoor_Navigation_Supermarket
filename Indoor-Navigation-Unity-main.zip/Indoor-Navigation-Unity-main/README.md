# Indoor-Navigation-Unity
Indoor Navigation
"Unity Indoor Navigation: Create immersive 3D representations of indoor spaces with pathfinding using Unity's NavMesh system. 
This repository includes features for user controls, a navigation UI, and optional integration of AR/VR for an engaging indoor navigation experience."

<h2>It is a Semester project which we have finished developing for our college campus</h2>

<p>Using only 3D objects like speare, cube and probuilder we developed the indoor navigation</p>
