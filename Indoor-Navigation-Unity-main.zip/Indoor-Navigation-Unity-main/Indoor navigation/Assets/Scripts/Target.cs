using System;
using UnityEngine;

[Serializable]

public class Target{
	public string Name;
	public GameObject PositionObject;
}